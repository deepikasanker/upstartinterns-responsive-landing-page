# Task 04 - Authenticated App

A small Flask web app for the UpStartInterns Task 04 requirement.

## Features

- User registration and login
- Passwords stored as secure hashes, never plain text
- Session-based authentication
- Each user can see only their own notes
- Database queries use the signed-in user's ID
- Logout support
- Ready for deployment with Gunicorn
- Render deployment configuration included

## Run locally

### 1. Create a virtual environment

```bash
python -m venv venv
```

Windows:
```bash
venv\Scripts\activate
```

### 2. Install packages

```bash
pip install -r requirements.txt
```

### 3. Start the app

```bash
python app.py
```

Open:
`http://127.0.0.1:5000`

## GitHub

Create a GitHub repository and upload all project files.

Do NOT upload a real database file or secret key.

## Render deployment

1. Push the project to GitHub.
2. Open Render and create a new Web Service.
3. Connect the GitHub repository.
4. Build command:
   `pip install -r requirements.txt`
5. Start command:
   `gunicorn app:app`
6. Add environment variable:
   `SECRET_KEY`
   with a long random value.
7. Deploy.
8. Copy the public `onrender.com` URL for the Task 04 submission.

## Important database note

This demo uses SQLite for simplicity. On free cloud web services, local disk may be ephemeral, so database data can be reset after a redeploy/restart. For a production app, replace SQLite with a managed PostgreSQL database.

## Task 04 verification

- Register User A and add a note.
- Log out.
- Register/login as User B.
- User B should not see User A's note.
- Add a User B note.
- Log out and log in as User A again.
- User A should only see User A's note.

This demonstrates user-scoped data access.
